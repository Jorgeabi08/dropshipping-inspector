from typing import Dict
from pathlib import Path
import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración de la aplicación
APP_CONFIG = {
    "PRODUCT_ID": os.getenv("PRODUCT_ID", "TU_PRODUCT_ID_DE_GUMROAD"),
    "LICENSE_CACHE_FILE": "license_cache.json",
    "DEFAULT_EXPORT_DIR": "exports",
    "DEFAULT_SLEEP_BETWEEN": 1.0,
    "DEV_MODE": True  # Modo desarrollo
}

# Configuración por marketplace
MARKETPLACE_CONFIG: Dict[str, Dict] = {
    "mercadolibre": {
        "country_code": "MLM",  # México por defecto
        "sleep_between": 1.0,
        "max_retries": 3,
    },
    "amazon": {
        "marketplace": "amazon.com",
        "sleep_between": 2.0,
        "max_retries": 3,
    },
    "aliexpress": {
        "marketplace": "aliexpress.com",
        "sleep_between": 2.0,
        "max_retries": 3,
    }
}

# Asegurarse de que existe el directorio de exportación
Path(APP_CONFIG["DEFAULT_EXPORT_DIR"]).mkdir(exist_ok=True)