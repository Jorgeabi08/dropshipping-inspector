# license_check.py
import os
import json
import requests
from pathlib import Path

CACHE_DIR = Path.home() / ".dropshipping_inspector"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
CACHE_FILE = CACHE_DIR / "license.json"

GUMROAD_VERIFY_URL = "https://api.gumroad.com/v2/licenses/verify"

def verify_license(license_key: str, product_id: str) -> dict:
    """
    Verifica la licencia con Gumroad. Devuelve el JSON de respuesta.
    Importante: para productos creados desde 2023-01-09 usar product_id.
    """
    data = {
        "license_key": license_key,
        "product_id": product_id
    }
    try:
        resp = requests.post(GUMROAD_VERIFY_URL, data=data, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        # Retorna error estructurado para que el CLI lo maneje
        return {"success": False, "message": f"Network/API error: {e}"}

def cache_license_info(license_key: str, info: dict):
    payload = {
        "license_key": license_key,
        "info": info
    }
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(payload, f)

def load_cached_license() -> dict | None:
    if CACHE_FILE.exists():
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
    return None
