#!/usr/bin/env python3
import argparse
from datetime import datetime
from pathlib import Path
from typing import Optional, List
from .license_check import verify_license, cache_license_info, load_cached_license
from .config import APP_CONFIG, MARKETPLACE_CONFIG
from .scrapers.mercadolibre import MercadoLibreScraper
from .scrapers.amazon import AmazonScraper
from .scrapers.aliexpress import AliExpressScraper

def check_license(license_key: str) -> bool:
    # En modo desarrollo, omitir verificación de licencia
    if APP_CONFIG.get("DEV_MODE"):
        print("[DEV] Omitiendo verificación de licencia")
        return True
        
    # Intenta cargar cache primero
    cached = load_cached_license()
    if cached and cached.get("license_key") == license_key:
        info = cached.get("info", {})
        if info.get("success"):
            print("[cache] Licencia válida (cached).")
            return True
            
    # Verificación online
    print("Verificando licencia en Gumroad...")
    res = verify_license(license_key, APP_CONFIG["PRODUCT_ID"])
    if res.get("success"):
        cache_license_info(license_key, res)
        print("Licencia válida.")
        return True
        
    print("Licencia inválida o expirada.")
    return False

def get_scraper(marketplace: str, country_code: Optional[str] = None, use_proxies: bool = False, proxy_list: Optional[List[str]] = None):
    """Retorna el scraper apropiado según el marketplace seleccionado"""
    config = MARKETPLACE_CONFIG.get(marketplace, {})
    
    if marketplace == "mercadolibre":
        scraper = MercadoLibreScraper(
            country_code=country_code or config.get("country_code", "MLM"),
            sleep_between=config.get("sleep_between", 1.0),
            use_proxies=use_proxies
        )
    elif marketplace == "amazon":
        scraper = AmazonScraper(
            marketplace=config.get("marketplace", "amazon.com"),
            sleep_between=config.get("sleep_between", 2.0),
            use_proxies=use_proxies
        )
    elif marketplace == "aliexpress":
        scraper = AliExpressScraper(
            sleep_between=config.get("sleep_between", 2.0),
            use_proxies=use_proxies
        )
    else:
        raise ValueError(f"Marketplace no soportado: {marketplace}")
    
    # Si se proporcionaron proxies, añadirlos al scraper
    if use_proxies and proxy_list:
        scraper.add_proxies_from_list(proxy_list)
    
    return scraper

def main():
    parser = argparse.ArgumentParser(prog="inspector")
    subparsers = parser.add_subparsers(dest="command")
    
    # Comando scrape
    scrape_parser = subparsers.add_parser("scrape", help="Buscar productos")
    scrape_parser.add_argument(
        "marketplace",
        choices=["mercadolibre", "amazon", "aliexpress"],
        help="Marketplace donde buscar"
    )
    scrape_parser.add_argument(
        "query",
        help="Término de búsqueda"
    )
    scrape_parser.add_argument(
        "--country",
        help="Código de país (ejemplo: MLM para México)",
        default=None
    )
    scrape_parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Número máximo de resultados"
    )
    scrape_parser.add_argument(
        "--license",
        help="Clave de licencia",
        required=True
    )
    scrape_parser.add_argument(
        "--use-proxies",
        action="store_true",
        help="Usar proxies para las peticiones"
    )
    scrape_parser.add_argument(
        "--proxy-list",
        help="Archivo con lista de proxies (uno por línea en formato host:port)",
        type=argparse.FileType('r')
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
        
    if not check_license(args.license):
        return
        
    if args.command == "scrape":
        try:
            # Leer lista de proxies si se proporcionó
            proxy_list = None
            if args.proxy_list:
                proxy_list = [line.strip() for line in args.proxy_list if line.strip()]
            
            scraper = get_scraper(
                args.marketplace,
                args.country,
                use_proxies=args.use_proxies,
                proxy_list=proxy_list
            )
            
            print(f"Buscando '{args.query}' en {args.marketplace}...")
            if args.use_proxies:
                print("Usando proxies para las peticiones...")
            
            products = scraper.search_products(args.query, args.limit)
            
            if not products:
                print("No se encontraron resultados.")
                return
                
            # Crear nombre de archivo con timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = Path(APP_CONFIG["DEFAULT_EXPORT_DIR"]) / f"{args.marketplace}_{timestamp}.csv"
            
            scraper.export_to_csv(products, filename)
            print(f"Se encontraron {len(products)} productos.")
            print(f"Resultados exportados a: {filename}")
            
        except NotImplementedError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Error inesperado: {e}")

if __name__ == "__main__":
    main()